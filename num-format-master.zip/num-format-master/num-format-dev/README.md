# num-format-dev

* Utility crate for programmatically generating a rust module / enum from CLDR json files.
* **Not** published on [crates.io](https://www.crates.io)
