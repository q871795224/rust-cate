#!/usr/bin/env bash

cargo bench --manifest-path num-format-benches/Cargo.toml
